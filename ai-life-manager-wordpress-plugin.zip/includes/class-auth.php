<?php

if (!defined('ABSPATH')) {
    exit;
}

const ALM_FRONTEND_BASE_URL = 'https://ai-life-manager.netlify.app';

const ALM_EMAIL_VERIFIED_META = 'alm_email_verified';
const ALM_EMAIL_TOKEN_META = 'alm_email_verification_token';
const ALM_EMAIL_TOKEN_EXPIRES_META = 'alm_email_verification_expires';

class ALM_Auth {

    public function __construct() {

        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes() {

        register_rest_route(
            'alm/v1',
            '/auth/register',
            [
                'methods' => 'POST',
                'callback' => [$this, 'register_user'],
                'permission_callback' => '__return_true'
            ]
        );

        register_rest_route(
            'alm/v1',
            '/auth/login',
            [
                'methods' => 'POST',
                'callback' => [$this, 'login_user'],
                'permission_callback' => '__return_true'
            ]
        );

        register_rest_route(
            'alm/v1',
            '/auth/me',
            [
                'methods' => 'GET',
                'callback' => [$this, 'current_user'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                }
            ]
        );
        
        // Email verification endpoint
        register_rest_route(
            'alm/v1',
            '/auth/verify-email',
            [
                'methods' => 'POST',
                'callback' => [$this, 'verify_email'],
                'permission_callback' => '__return_true'
            ]
        );

        // Email verification redirect endpoint
        register_rest_route(
            'alm/v1',
            '/auth/verify-email-redirect',
            [
                'methods' => 'GET',
                'callback' => [$this, 'verify_email_redirect'],
                'permission_callback' => '__return_true'
            ]
        );
    }

    public function register_user($request) {

        $email = sanitize_email($request['email']);
        $password = $request['password'];
        $name = sanitize_text_field($request['name']);

        if (email_exists($email)) {

            return new WP_Error(
                'email_exists',
                'Email already registered',
                ['status' => 400]
            );
        }

                $user_id = wp_create_user(
            $email,
            $password,
            $email
        );

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        wp_update_user([
            'ID' => $user_id,
            'display_name' => $name
        ]);

        // Set email verification meta
        update_user_meta($user_id, ALM_EMAIL_VERIFIED_META, '0');
        $token = $this->generate_verification_token($user_id, $email);
        $verification_link = $this->send_verification_email($user_id, $email, $token);

                $response = [
            'success' => true,
            'user_id' => $user_id,
            'verification_required' => true,
            'message' => 'Registration successful. Please verify your email.'
        ];
        if ( defined('WP_DEBUG') && WP_DEBUG ) {
            $response['debug_token'] = $token;
            $response['debug_link'] = $verification_link;
        }
        return $response;
    }

    public function login_user($request) {

        $creds = [
            'user_login' => sanitize_email($request['email']),
            'user_password' => $request['password'],
            'remember' => true
        ];

        $user = wp_signon($creds);

        if (is_wp_error($user)) {

            return new WP_Error(
                'invalid_login',
                'Invalid credentials',
                ['status' => 401]
            );
        }

                // Ensure email is verified
        if (get_user_meta($user->ID, ALM_EMAIL_VERIFIED_META, true) !== '1') {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Please verify your email before logging in.'
            ], 403);
        }

        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);

        // Set a cookie with user info for front‑end persistence (non‑HttpOnly so JS can read)
        $user_data = json_encode([
            'id'    => $user->ID,
            'name'  => $user->display_name,
            'email' => $user->user_email,
        ]);
        // Cookie lasts 7 days, accessible on client side
        setcookie('alm_user_data', $user_data, time() + DAY_IN_SECONDS * 7, '/', '', false, false);

        return [
            'success' => true,
            'user_id' => $user->ID,
            'name'    => $user->display_name,
            'email'   => $user->user_email,
        ];
    }

    public function current_user() {

        $user = wp_get_current_user();

        return [
            'id' => $user->ID,
            'name' => $user->display_name,
            'email' => $user->user_email
        ];
    }
    // Generate a random verification token and store hashed version
    private function generate_verification_token($user_id, $email) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + DAY_IN_SECONDS;
        update_user_meta($user_id, ALM_EMAIL_TOKEN_META, hash('sha256', $token));
        update_user_meta($user_id, ALM_EMAIL_TOKEN_EXPIRES_META, $expires);
        return $token;
    }

    // Send verification email to the user
    private function send_verification_email($user_id, $email, $token) {
        // Build a verification link that will log the user in and redirect
        $frontend_url = apply_filters(
            'alm_auth_frontend_verify_url',
            // Default points to our new redirect endpoint inside WordPress
            site_url('/wp-json/alm/v1/auth/verify-email-redirect')
        );
        $verification_link = add_query_arg([
            'email' => rawurlencode($email),
            'token' => rawurlencode($token),
        ], $frontend_url);

        error_log('Verification link for ' . $email . ': ' . $verification_link);

        // Prepare e‑mail content
        $subject = 'Verify your AI Life Manager account';
        $message = "Hi,\n\nPlease verify your email address by clicking the link below:\n$verification_link\n\nThis link expires in 24 hours.\n\nIf you did not sign up, you can ignore this email.";
        $headers = ['Content-Type: text/plain; charset=UTF-8', 'From: no-reply@ai-life-manager.com'];
        $sent = wp_mail($email, $subject, $message, $headers);
        if ( ! $sent ) {
            error_log('Verification email failed to send to ' . $email);
        }
        return $verification_link;
    }

    // Endpoint to verify email token (POST) – API usage
    public function verify_email( $request ) {
        $email = sanitize_email( $request['email'] );
        $token = sanitize_text_field( $request['token'] );
        if ( ! $email || ! $token ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid verification link.' ], 400 );
        }
        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'User not found.' ], 404 );
        }
        $stored_hash = get_user_meta( $user->ID, ALM_EMAIL_TOKEN_META, true );
        $expires = (int) get_user_meta( $user->ID, ALM_EMAIL_TOKEN_EXPIRES_META, true );
        if ( ! $stored_hash || ! $expires || time() > $expires ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Verification link has expired.' ], 400 );
        }
        if ( ! hash_equals( $stored_hash, hash( 'sha256', $token ) ) ) {
            return new WP_REST_Response( [ 'success' => false, 'message' => 'Invalid verification token.' ], 400 );
        }
        // Mark email as verified and clean up token meta
        update_user_meta( $user->ID, ALM_EMAIL_VERIFIED_META, '1' );
        delete_user_meta( $user->ID, ALM_EMAIL_TOKEN_META );
        delete_user_meta( $user->ID, ALM_EMAIL_TOKEN_EXPIRES_META );
        return new WP_REST_Response( [ 'success' => true, 'message' => 'Your email has been verified. You can now log in.' ], 200 );
    }

    // Endpoint to verify email token and log the user in (GET) – for click‑through links
    public function verify_email_redirect() {
        $email = isset( $_GET['email'] ) ? sanitize_email( $_GET['email'] ) : '';
        $token = isset( $_GET['token'] ) ? sanitize_text_field( $_GET['token'] ) : '';
        $redirect_url = apply_filters( 'alm_auth_login_redirect_url', ALM_FRONTEND_BASE_URL . '/' );

        if ( ! $email || ! $token ) {
            wp_redirect( $redirect_url );
            exit;
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            wp_redirect( $redirect_url . '?error=user_not_found' );
            exit;
        }

        // Early check if already verified
        if ( get_user_meta( $user->ID, ALM_EMAIL_VERIFIED_META, true ) === '1' ) {
            wp_redirect( $redirect_url . '?verified=already' );
            exit;
        }

        $stored_hash = get_user_meta( $user->ID, ALM_EMAIL_TOKEN_META, true );
        $expires = (int) get_user_meta( $user->ID, ALM_EMAIL_TOKEN_EXPIRES_META, true );
        if ( ! $stored_hash || ! $expires || time() > $expires ) {
            wp_redirect( $redirect_url . '?error=expired' );
            exit;
        }
        if ( ! hash_equals( $stored_hash, hash( 'sha256', $token ) ) ) {
            wp_redirect( $redirect_url . '?error=invalid_token' );
            exit;
        }
        // Verify user
        update_user_meta( $user->ID, ALM_EMAIL_VERIFIED_META, '1' );
        delete_user_meta( $user->ID, ALM_EMAIL_TOKEN_META );
        delete_user_meta( $user->ID, ALM_EMAIL_TOKEN_EXPIRES_META );

        // Log the user in
        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID );

        // Set a cookie with user info for front‑end persistence (non‑HttpOnly)
        $user_data = json_encode([
            'id'    => $user->ID,
            'name'  => $user->display_name,
            'email' => $user->user_email,
        ]);
        setcookie('alm_user_data', $user_data, time() + DAY_IN_SECONDS * 7, '/', '', false, false);

        // Redirect to front‑end or dashboard
        wp_redirect( $redirect_url . '?verified=success' );
        exit;
    }

}

/**
 * Add a one-minute cron schedule.
 */
add_filter( 'cron_schedules', 'alm_add_minute_schedule' );
function alm_add_minute_schedule( $schedules ) {
    $schedules['minute'] = [
        'interval' => 60,
        'display'  => esc_html__( 'Every Minute' ),
    ];
    return $schedules;
}

/**
 * Schedule notification cron job on plugin load.
 */
if ( ! wp_next_scheduled( 'alm_send_notifications' ) ) {
    // Run every minute to catch upcoming notifications.
    wp_schedule_event( time(), 'minute', 'alm_send_notifications' );
}
add_action( 'alm_send_notifications', 'alm_send_notifications_callback' );

/**
 * Cron callback to send task and bill reminder emails.
 */
function alm_send_notifications_callback() {
    // Current time.
    $now = current_time( 'timestamp' );

    // ----- Task notifications (10 minutes before) -----
    $task_args = [
        'post_type'   => 'task',
        'post_status' => 'publish',
        'meta_query'  => [
            [
                'key'     => 'due_date',
                'value'   => [ $now + 30 * MINUTE_IN_SECONDS, $now + 30 * MINUTE_IN_SECONDS + 60 ],
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC',
            ],
        ],
        'fields' => 'ids',
    ];
    $task_ids = get_posts( $task_args );
    foreach ( $task_ids as $task_id ) {
        $user_id = get_post_field( 'post_author', $task_id );
        $user = get_user_by( 'ID', $user_id );
        if ( ! $user ) continue;
        $title   = get_the_title( $task_id );
        $message = "Reminder: Your task '{$title}' is due in 30 minutes.";
        wp_mail( $user->user_email, 'Upcoming Task Reminder', $message );
    }

    // ----- Bill notifications (1 day before) -----
    $bill_args = [
        'post_type'   => 'bill',
        'post_status' => 'publish',
        'meta_query'  => [
            [
                'key'     => 'due_date',
                'value'   => [ $now + DAY_IN_SECONDS, $now + DAY_IN_SECONDS + 86400 ],
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC',
            ],
        ],
        'fields' => 'ids',
    ];
    $bill_ids = get_posts( $bill_args );
    foreach ( $bill_ids as $bill_id ) {
        $user_id = get_post_field( 'post_author', $bill_id );
        $user = get_user_by( 'ID', $user_id );
        if ( ! $user ) continue;
        $title   = get_the_title( $bill_id );
        $message = "Reminder: Your bill '{$title}' is due in 1 day.";
        wp_mail( $user->user_email, 'Upcoming Bill Reminder', $message );
    }
}

/**
 * Clean up scheduled event on plugin deactivation.
 */
function alm_cleanup_notifications() {
    $timestamp = wp_next_scheduled( 'alm_send_notifications' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'alm_send_notifications' );
    }
}
register_deactivation_hook( __FILE__, 'alm_cleanup_notifications' );