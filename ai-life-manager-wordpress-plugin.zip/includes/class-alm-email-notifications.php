<?php

if (!defined('ABSPATH')) {
    exit;
}

class ALM_Email_Notifications {

    public function __construct() {
        add_action('alm_send_email_notifications_cron', [$this, 'send_notifications']);
    }

    /**
     * Periodically checks and sends email notifications for upcoming tasks and bills.
     */
    public function send_notifications() {
        global $wpdb;

        $now = current_time('timestamp');

        /* -------------------------------------------------------------
           1. UPCOMING TASK EMAIL REMINDERS
        ------------------------------------------------------------- */
        $tasks_table = $wpdb->prefix . 'alm_tasks';
        
        // Define limits: starting between 2 hours ago and 15 minutes from now
        $start_limit = date('Y-m-d H:i:s', $now - 2 * HOUR_IN_SECONDS);
        $end_limit   = date('Y-m-d H:i:s', $now + 15 * MINUTE_IN_SECONDS);

        $upcoming_tasks = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.*, u.user_email, u.display_name
                 FROM {$tasks_table} t
                 INNER JOIN {$wpdb->users} u ON t.user_id = u.ID
                 WHERE t.status = 'pending'
                   AND t.email_sent = 0
                   AND t.start_time >= %s
                   AND t.start_time <= %s",
                $start_limit,
                $end_limit
            ),
            ARRAY_A
        );

        if (!empty($upcoming_tasks)) {
            foreach ($upcoming_tasks as $task) {
                $email = $task['user_email'];
                $subject = 'Reminder: Upcoming Task - ' . $task['title'];
                
                $email_content = $this->get_task_email_body($task);
                $html_message = $this->get_html_wrapper('Upcoming Task Reminder', $email_content);

                $headers = array('Content-Type: text/html; charset=UTF-8');
                $sent = wp_mail($email, $subject, $html_message, $headers);

                if ($sent) {
                    $wpdb->update(
                        $tasks_table,
                        ['email_sent' => 1],
                        ['id' => $task['id']]
                    );
                }
            }
        }

        /* -------------------------------------------------------------
           2. UPCOMING BILL EMAIL REMINDERS
        ------------------------------------------------------------- */
        $bills_table = $wpdb->prefix . 'alm_bills';

        $upcoming_bills = $wpdb->get_results(
            "SELECT b.*, u.user_email, u.display_name
             FROM {$bills_table} b
             INNER JOIN {$wpdb->users} u ON b.user_id = u.ID
             WHERE b.status != 'paid'
               AND b.email_sent = 0",
            ARRAY_A
        );

        if (!empty($upcoming_bills)) {
            $today_str = date('Y-m-d', $now);
            $today_ts = strtotime($today_str);

            foreach ($upcoming_bills as $bill) {
                $due_date_ts = strtotime($bill['due_date']);
                $reminder_days = intval($bill['reminder_days']);
                
                // Calculate when to start showing reminders
                $reminder_start_ts = $due_date_ts - ($reminder_days * DAY_IN_SECONDS);

                // Send email if today falls in the reminder range
                if ($today_ts >= $reminder_start_ts && $today_ts <= $due_date_ts) {
                    $email = $bill['user_email'];
                    $subject = 'Reminder: Upcoming Bill Due - ' . $bill['bill_name'];
                    
                    $email_content = $this->get_bill_email_body($bill);
                    $html_message = $this->get_html_wrapper('Upcoming Bill Reminder', $email_content);

                    $headers = array('Content-Type: text/html; charset=UTF-8');
                    $sent = wp_mail($email, $subject, $html_message, $headers);

                    if ($sent) {
                        $wpdb->update(
                            $bills_table,
                            ['email_sent' => 1],
                            ['id' => $bill['id']]
                        );
                    }
                }
            }
        }
    }

    /**
     * Helper to get the frontend base URL dynamically (defaulting to Netlify live URL).
     */
    private function get_frontend_base_url() {
        $default_url = 'https://ai-life-manager.netlify.app';
        if (defined('ALM_FRONTEND_URL')) {
            $default_url = rtrim(ALM_FRONTEND_URL, '/');
            if (preg_match('/\/verify-email$/', $default_url)) {
                $default_url = preg_replace('/\/verify-email$/', '', $default_url);
            }
        } else {
            $db_url = get_option('alm_frontend_url');
            if ($db_url) {
                $default_url = rtrim($db_url, '/');
                if (preg_match('/\/verify-email$/', $default_url)) {
                    $default_url = preg_replace('/\/verify-email$/', '', $default_url);
                }
            }
        }
        return $default_url;
    }

    /**
     * Builds the content for a Task Reminder email.
     */
    private function get_task_email_body($task) {
        $start_time = strtotime($task['start_time']);
        $start_time_formatted = date('h:i A \o\n d M Y', $start_time);
        
        $priority_colors = [
            'high'   => '#ef4444',
            'medium' => '#f59e0b',
            'low'    => '#10b981'
        ];
        $priority = strtolower($task['priority']);
        $priority_color = isset($priority_colors[$priority]) ? $priority_colors[$priority] : '#64748b';
        $priority_display = ucfirst($priority);

        $description = !empty($task['description']) ? $task['description'] : 'No description provided.';
        $frontend_url = $this->get_frontend_base_url() . '/tasks';

        $output = '
        <h2>Hello ' . esc_html($task['display_name']) . ',</h2>
        <p>This is a reminder that you have a task starting soon.</p>
        
        <div class="detail-card">
            <div class="detail-item">
                <span class="detail-label">Task:</span>
                <span class="detail-value" style="font-weight: 600;">' . esc_html($task['title']) . '</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Starts:</span>
                <span class="detail-value">' . esc_html($start_time_formatted) . '</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Priority:</span>
                <span class="detail-value" style="color: ' . $priority_color . '; font-weight: 600;">' . esc_html($priority_display) . '</span>
            </div>
            <div class="detail-item" style="margin-top: 15px;">
                <span class="detail-label" style="display: block; margin-bottom: 5px;">Description:</span>
                <span class="detail-value" style="display: block; color: #475569; font-style: italic;">' . nl2br(esc_html($description)) . '</span>
            </div>
        </div>

        <p>Please log in to your dashboard to manage your planner.</p>
        <div class="btn-container">
            <a href="' . esc_url($frontend_url) . '" class="btn" target="_blank">View Your Tasks</a>
        </div>
        ';

        return $output;
    }

    /**
     * Builds the content for a Bill Reminder email.
     */
    private function get_bill_email_body($bill) {
        $due_date = strtotime($bill['due_date']);
        $due_date_formatted = date('d M Y', $due_date);
        
        $amount_formatted = '₹' . number_format($bill['amount'], 2);
        $recurring_display = ucfirst(esc_html($bill['recurring']));
        
        $frontend_url = $this->get_frontend_base_url() . '/bills';

        $output = '
        <h2>Hello ' . esc_html($bill['display_name']) . ',</h2>
        <p>This is a reminder that you have an upcoming bill payment due soon.</p>
        
        <div class="detail-card">
            <div class="detail-item">
                <span class="detail-label">Bill Name:</span>
                <span class="detail-value" style="font-weight: 600;">' . esc_html($bill['bill_name']) . '</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Amount:</span>
                <span class="detail-value" style="font-weight: 600; color: #0f172a;">' . $amount_formatted . '</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Due Date:</span>
                <span class="detail-value" style="color: #ef4444; font-weight: 600;">' . esc_html($due_date_formatted) . '</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Recurring:</span>
                <span class="detail-value">' . $recurring_display . '</span>
            </div>
        </div>

        <p>Please log in to your dashboard to record this payment once settled.</p>
        <div class="btn-container">
            <a href="' . esc_url($frontend_url) . '" class="btn" target="_blank">Manage Your Bills</a>
        </div>
        ';

        return $output;
    }

    /**
     * Wraps the email body in a beautiful, premium HTML template.
     */
    private function get_html_wrapper($title, $content) {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>' . esc_html($title) . '</title>
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
                    background-color: #f8fafc;
                    color: #1e293b;
                    margin: 0;
                    padding: 0;
                    -webkit-font-smoothing: antialiased;
                }
                .wrapper {
                    width: 100%;
                    background-color: #f8fafc;
                    padding: 40px 0;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #ffffff;
                    border-radius: 16px;
                    overflow: hidden;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                }
                .header {
                    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
                    padding: 40px 20px;
                    text-align: center;
                    color: #ffffff;
                }
                .header h1 {
                    margin: 0;
                    font-size: 28px;
                    font-weight: 700;
                    letter-spacing: -0.025em;
                }
                .header p {
                    margin: 10px 0 0 0;
                    font-size: 16px;
                    opacity: 0.9;
                }
                .content {
                    padding: 40px 30px;
                    line-height: 1.6;
                    color: #334155;
                }
                .content h2 {
                    font-size: 20px;
                    font-weight: 600;
                    color: #0f172a;
                    margin-top: 0;
                    margin-bottom: 16px;
                }
                .detail-card {
                    background-color: #f1f5f9;
                    border-left: 4px solid #6366f1;
                    padding: 20px;
                    border-radius: 8px;
                    margin-bottom: 24px;
                }
                .detail-item {
                    margin-bottom: 10px;
                    font-size: 15px;
                }
                .detail-item:last-child {
                    margin-bottom: 0;
                }
                .detail-label {
                    font-weight: 600;
                    color: #475569;
                    display: inline-block;
                    width: 120px;
                }
                .detail-value {
                    color: #0f172a;
                }
                .btn-container {
                    text-align: center;
                    margin-top: 30px;
                    margin-bottom: 10px;
                }
                .btn {
                    background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
                    color: #ffffff !important;
                    text-decoration: none;
                    padding: 14px 30px;
                    border-radius: 9999px;
                    font-weight: 600;
                    font-size: 16px;
                    display: inline-block;
                    box-shadow: 0 4px 6px -1px rgba(99, 102, 241, 0.3), 0 10px 15px -3px rgba(99, 102, 241, 0.2);
                }
                .footer {
                    background-color: #f8fafc;
                    padding: 24px 30px;
                    text-align: center;
                    font-size: 13px;
                    color: #64748b;
                    border-top: 1px solid #e2e8f0;
                }
                .footer p {
                    margin: 0;
                }
            </style>
        </head>
        <body>
            <div class="wrapper">
                <div class="container">
                    <div class="header">
                        <h1>AI Life Manager</h1>
                        <p>' . esc_html($title) . '</p>
                    </div>
                    <div class="content">
                        ' . $content . '
                    </div>
                    <div class="footer">
                        <p>&copy; ' . date('Y') . ' AI Life Manager. All rights reserved.</p>
                        <p style="margin-top: 8px;">This is an automated notification. Please do not reply directly to this email.</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        ';
    }
}
