<?php
/**
 * Plugin Name: AI Life Manager
 * Plugin URI: https://yourdomain.com
 * Description: Daily Planner, Expense Tracker, Bill Reminder SaaS Backend
 * Version: 1.0.0
 * Author: Subrata Halder
 * Text Domain: ai-life-manager
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ALM_VERSION', '1.0.0');
define('ALM_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ALM_PLUGIN_URL', plugin_dir_url(__FILE__));

function alm_get_request_user_id() {
    $user_id = intval($_SERVER['HTTP_X_ALM_USER_ID'] ?? 0);

    if (!$user_id) {
        return 0;
    }

    $user = get_user_by('ID', $user_id);

    if (!$user) {
        return 0;
    }

    return $user_id;
}

function alm_require_request_user_id() {
    $user_id = alm_get_request_user_id();

    if (!$user_id) {
        return new WP_Error(
            'unauthorized_user',
            'Unauthorized user.',
            ['status' => 401]
        );
    }

    return $user_id;
}

// Allow custom CORS headers
add_filter('rest_allowed_cors_headers', function($headers) {
    if (!in_array('X-ALM-User-ID', $headers)) {
        $headers[] = 'X-ALM-User-ID';
    }
    return $headers;
});

require_once ALM_PLUGIN_PATH . 'includes/class-db.php';
require_once ALM_PLUGIN_PATH . 'includes/class-loader.php';

// Custom activation hook (creates tables & schedules cron)
function alm_activate_plugin() {
    ALM_DB::create_tables();
    if (!wp_next_scheduled('alm_send_email_notifications_cron')) {
        wp_schedule_event(time(), 'every_five_minutes', 'alm_send_email_notifications_cron');
    }
}
register_activation_hook(__FILE__, 'alm_activate_plugin');

// Custom deactivation hook (unschedules cron)
function alm_deactivate_plugin() {
    $timestamp = wp_next_scheduled('alm_send_email_notifications_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'alm_send_email_notifications_cron');
    }
}
register_deactivation_hook(__FILE__, 'alm_deactivate_plugin');

// Define custom cron intervals
add_filter('cron_schedules', 'alm_custom_cron_schedules');
function alm_custom_cron_schedules($schedules) {
    if (!isset($schedules['every_five_minutes'])) {
        $schedules['every_five_minutes'] = array(
            'interval' => 300, // 5 minutes in seconds
            'display'  => __('Every 5 Minutes', 'ai-life-manager')
        );
    }
    return $schedules;
}

function alm_init_plugin() {
    new ALM_Loader();
}
add_action('plugins_loaded', 'alm_init_plugin');
